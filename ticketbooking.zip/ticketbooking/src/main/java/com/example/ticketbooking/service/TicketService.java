package com.example.ticketbooking.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ticketbooking.entity.TicketManage;
import com.example.ticketbooking.repository.TicketRepository;

@Service
public class TicketService {
	
	@Autowired
	private TicketRepository ticketRepo;
	
	public List<TicketManage> getTickets() {
		return ticketRepo.findAll();
	}
	
	public Optional<TicketManage> getTicketById(long ticketId) {
		Optional<TicketManage> t=ticketRepo.findById(ticketId);
		if(t.isPresent()) {
			
			return ticketRepo.findById(ticketId);
		}
		else
			return null;
	}
	
	
	public void createTicket(TicketManage ticket) {
		ticketRepo.save(ticket);
	}
	
	
	public void updateTicket(long ticketId, long userId,String category,long luggageWeight,String source,String destination,LocalDateTime arrivaldateTime,LocalDateTime reachdateTime) {
		Optional<TicketManage> t=ticketRepo.findById(ticketId);
		if(t.isPresent()) {
			TicketManage to=t.get();
			to.setCategory(category);
			to.setDestination(destination);
			to.setLuggageWeight(luggageWeight);
			to.setSource(source);
			to.setUserId(userId);
			to.setReachdateTime(reachdateTime);
			to.setArrivaldateTime(arrivaldateTime);
			ticketRepo.save(to);
		}

	}
	
	public void deleteTicket(long ticketId) {
		 ticketRepo.deleteById(ticketId);
	}
	

}

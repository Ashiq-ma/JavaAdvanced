package com.example.ticketbooking.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class TicketManage {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ticketId;
	private long userId;
	private String category;
	private long luggageWeight;
	private String source;
	private String destination;
	private LocalDateTime arrivaldateTime;
	private LocalDateTime reachdateTime;
	
	
	public long getTicketId() {
		return ticketId;
	}
	public void setTicketId(long ticketId) {
		this.ticketId = ticketId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public long getLuggageWeight() {
		return luggageWeight;
	}
	public void setLuggageWeight(long luggageWeight) {
		this.luggageWeight = luggageWeight;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public LocalDateTime getArrivaldateTime() {
		return arrivaldateTime;
	}
	public void setArrivaldateTime(LocalDateTime arrivaldateTime) {
		this.arrivaldateTime = arrivaldateTime;
	}
	public LocalDateTime getReachdateTime() {
		return reachdateTime;
	}
	public void setReachdateTime(LocalDateTime reachdateTime) {
		this.reachdateTime = reachdateTime;
	}
	
	
	
	
	
	

}
